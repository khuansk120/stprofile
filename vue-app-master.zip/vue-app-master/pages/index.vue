<template>
  <div>Hello world</div>
</template>
<script>
export default {
  data() {
    return {
      id: 1,
    }
  },
}
</script>
