export default {
  socket: {
    url: 'http://localhost:8999',
  },
}
